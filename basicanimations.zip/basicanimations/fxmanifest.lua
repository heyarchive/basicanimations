fx_version 'adamant'
games { 'gta5' };

Author "Archive Was Here" 
Description "Basic Animation Script For FiveM Roleplay"
Version "1.0.0"

client_script 'cl_pointfinger.lua'
client_script 'cl_handsup.lua'