BASIC ANIMATIONS

## Installation
1. Download this repo
2. Copy the `basicanimations` folder to your server resources folder 
3. Make sure that the resource name is all lowercase. The resource will **not** work with uppercase letters in the name!
4. Add `ensure basicanimations` to your server.cfg
5. Restart the server

Its a really basic script but it includes pointing finger by clicking "B" and putting hands up by clicking "C" super simple!